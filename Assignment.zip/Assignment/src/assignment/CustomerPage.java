/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import static assignment.Assignment.orderArr;
import assignment.people.Courier;
import assignment.people.Customer;
import assignment.people.RoleEnum;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author asus
 */
public class CustomerPage extends JFrame implements ActionListener {
    
    private static Customer currentLogin;
    
    public static JPanel mainPanel;
    
    public static Button backBtn;
    
    public static Label editAccountTitleLabel, listOrderTitleLabel;   
    public static JPanel editPanel;
    public static Label IDLabel, IDLabel2, nameLabel, nameLabel2, telephoneLabel, telephoneLabel2, addressLabel, addressLabel2, roleLabel, roleLabel2;
    
    public static Button refreshBtn;
    DefaultTableModel tableModel2;
    public static JPanel orderTablePanel;
    public static JTable orderTable;
    public static JScrollPane orderScrollPane;
    String[] orderColumnNames = {"ORDER_ID", "CourierID", "CustomerID", "Charge", "Departure", "Destination", "StartTime", "EndTime", "Rating", "Feedback"};
    
    public CustomerPage(){
        this.setSize(1300,500);
        setLocation(300,200);
        //close the GUI and stop the system
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Font f = new Font(Font.SANS_SERIF,Font.BOLD,16);
        GridBagConstraints c;
        
        backBtn = new Button("Back to Login");
        backBtn.addActionListener(this);
                       
        editPanel = new JPanel();
        editPanel.setLayout(new GridBagLayout());
        
        editAccountTitleLabel =  new Label("Profile");
        editAccountTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 2;
        editPanel.add(editAccountTitleLabel, c );
        
        IDLabel = new Label("ID :");
        IDLabel2 = new Label("                   ");
        nameLabel = new Label("Name :");
        nameLabel2 = new Label("                   ");
        telephoneLabel = new Label("Telephone :");
        telephoneLabel2 = new Label("                   ");
        addressLabel = new Label("Address :");
        addressLabel2 = new Label("                   ");
        roleLabel = new Label("Role :");
        roleLabel2 = new Label("                   ");
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        editPanel.add(IDLabel, c);
        c.gridx = 1;
        c.gridy = 2;
        editPanel.add(nameLabel, c);
        c.gridx = 1;
        c.gridy = 3;
        editPanel.add(telephoneLabel, c);
        c.gridx = 1;
        c.gridy = 4;
        editPanel.add(addressLabel, c);
        c.gridx = 1;
        c.gridy = 5;
        editPanel.add(roleLabel, c);
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;
        editPanel.add(IDLabel2, c);
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        editPanel.add(nameLabel2, c);
        c.gridx = 2;
        c.gridy = 3;
        c.gridwidth = 2;
        editPanel.add(telephoneLabel2, c);
        c.gridx = 2;
        c.gridy = 4;
        c.gridwidth = 2;
        editPanel.add(addressLabel2, c);
        c.gridx = 2;
        c.gridy = 5;
        c.gridwidth = 2;
        editPanel.add(roleLabel2, c);
        
        refreshBtn = new Button("Refresh");
        refreshBtn.addActionListener(this);
       
        orderTablePanel = new JPanel();
        orderTablePanel.setLayout(new GridBagLayout());
        
        listOrderTitleLabel =  new Label("My Order");
        listOrderTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        orderTablePanel.add(listOrderTitleLabel, c );
        
        tableModel2 = new DefaultTableModel(orderColumnNames, 0);
        orderTable = new JTable(tableModel2) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        for(int i=0; i<10; i++){
            Object[] objs = {"","","","","","","","","",""};
            tableModel2.addRow(objs);
        }
        
        orderTable.getTableHeader().setMinimumSize(new Dimension(750,15));
        orderTable.setMinimumSize(new Dimension(750,400));
        orderTable.setCellSelectionEnabled(false);
        orderScrollPane = new JScrollPane(orderTable);
        orderScrollPane.setMinimumSize(new Dimension(750,500));
        orderScrollPane.setMaximumSize(new Dimension(750,500));
        
        TableColumn column = null;
        for (int i = 0; i < 5; i++) {
            column = orderTable.getColumnModel().getColumn(i);
            if (i == 0 || i == 3) {
                column.setPreferredWidth(55);
            } else if (i == 4 || i == 5) {
                column.setPreferredWidth(100);
            } else {
                column.setPreferredWidth(75);    
            }
        }
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        orderTablePanel.add(refreshBtn,c);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        orderTablePanel.add(orderTable.getTableHeader(),c);
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 2;
        orderTablePanel.add(orderTable,c);
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        mainPanel.add(backBtn, c);
        c.gridx = 1;
        c.gridy = 2;
        mainPanel.add(editPanel, c);

        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 1;
        //mainPanel.add(searchOrderPanel, c);
        c.gridx = 2;
        c.gridy = 2;
        mainPanel.add(orderTablePanel, c);
        
        add(mainPanel);
    }
    
    public void setCurrentLogin(Customer customer) {
        this.currentLogin = currentLogin;
    }
    public Customer getCurrentLogin() {
        return currentLogin;
    }
    
    public void loadProfileTextField(Customer currentLogin){
        this.currentLogin = currentLogin;
        IDLabel2.setText(String.valueOf(currentLogin.getId()));
        nameLabel2.setText(currentLogin.getName());
        roleLabel2.setText(currentLogin.getRole().toString());
        telephoneLabel2.setText(String.valueOf(currentLogin.getTelephone()));
        addressLabel2.setText(currentLogin.getAddress());
    };
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        if(e.getSource() == refreshBtn){
            tableModel2.removeRow(9);
            tableModel2.removeRow(8);
            tableModel2.removeRow(7);
            tableModel2.removeRow(6);
            tableModel2.removeRow(5);
            tableModel2.removeRow(4);
            tableModel2.removeRow(3);
            tableModel2.removeRow(2);
            tableModel2.removeRow(1);
            tableModel2.removeRow(0);
            int i=0;
            for(Order order : Assignment.orderArr){
                try{
                    if(order.getAssignedCourier().getId() == currentLogin.getId()) {
                        if(i != 9 && i<10){
                            Object[] objs = {order.getOrderId(),order.getAssignedCourier().getId(),order.getOwningCustomer().getId(),order.getCharge(),order.getDepartureAddress(),order.getDestinationAddress(),order.getSTART_TIME(),order.getEndTime(),order.getRating().toString(),order.getFeedback()};
                            tableModel2.addRow(objs);
                            i++;
                        } else if(i<10) {
                            Object[] objs = {"+","+","+","+","+","+","+","+","+","+"};
                            tableModel2.addRow(objs);
                            i++;
                        }
                    }
                } catch(Exception Ex) {}
            }
            for(; i<10; i++){
                Object[] objs = {"","","","","","","","","",""};
                tableModel2.addRow(objs);
            }
        }
        if(e.getSource() == backBtn){
            this.setVisible(false);
            Assignment.loginPage.setVisible(true);
        }
    }
}


