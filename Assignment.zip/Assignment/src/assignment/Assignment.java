/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import assignment.people.Courier;
import assignment.people.Customer;
import assignment.people.Manager;
import assignment.people.RoleEnum;
import assignment.people.MethodDirectory;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Assignment extends MethodDirectory {

    /**
     * @param args the command line arguments
     */
    public static ArrayList<Customer> customerArr = new ArrayList<Customer>();
    public static ArrayList<Courier> courierArr = new ArrayList<Courier>();
    public static ArrayList<Manager> managerArr = new ArrayList<Manager>();
    public static ArrayList<Order> orderArr = new ArrayList<Order>();
    
    public static LoginPage loginPage;
    public static CustomerPage customerPage = new CustomerPage();
    public static ManagerPage managerPage = new ManagerPage();
    public static CourierPage courierPage = new CourierPage();
    
    
    public static void main(String[] args) {
        try{
            Scanner s = new Scanner(new File("person.txt"));
            while(s.hasNext()){
                int ID = Integer.parseInt(s.nextLine());
                String NAME = s.nextLine();
                int telephone = Integer.parseInt(s.nextLine());
                String address = s.nextLine();
                String roleString = s.nextLine();
                RoleEnum role = RoleEnum.valueOf(roleString); 
                String password;
                switch(role){
                    case CUSTOMER:
                        Customer customer = new Customer(ID, NAME, telephone, address, role);
                        customerArr.add(customer);
                        break;
                    case COURIER:
                        password = s.nextLine();
                        Courier courier = new Courier(ID, NAME, telephone, address, role, password);
                        courierArr.add(courier);
                        break;
                    case MANAGER:
                        password = s.nextLine();
                        Manager manager = new Manager(ID, NAME, telephone, address, role, password);
                        managerArr.add(manager);
                        break;
                }
                s.nextLine();
            }
        } catch(Exception ex){
            System.out.println("Error reading person.txt "+ex);
        }
        try{
            Scanner s = new Scanner(new File("order.txt"));
            while(s.hasNext()){
                int ORDER_ID = Integer.parseInt(s.nextLine());
                
                Courier assignedCourier = null;
                
                try{
                int courierID = Integer.parseInt(s.nextLine());
                assignedCourier = assignedCourier.findCourierByID(courierID, courierArr);
                } catch (Exception Ex) {}
                
                int customerID = Integer.parseInt(s.nextLine());
                Customer owningCustomer = null;
                owningCustomer = owningCustomer.findCustomerByID(customerID, customerArr);
                
                int charge = Integer.parseInt(s.nextLine());
                String departureAddress = s.nextLine();
                String destinationAddress = s.nextLine();
                
                String str = s.nextLine();
                str = str.replace("T"," ");
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                LocalDateTime START_TIME = LocalDateTime.parse(str, formatter);
                
                str = s.nextLine();
                str = str.replace("T"," ");
                formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                LocalDateTime endTime = LocalDateTime.parse(str, formatter);
                
                String ratingString = s.nextLine();
                RatingEnum rating = RatingEnum.valueOf(ratingString);
                
                String feedback = s.nextLine();
                
                String statusString = s.nextLine();
                StatusEnum status = StatusEnum.valueOf(statusString);
                
                str = s.nextLine();
                
                Order order = new Order(ORDER_ID, assignedCourier, owningCustomer, charge, departureAddress, destinationAddress, START_TIME, endTime, rating, feedback, status);
                orderArr.add(order);
            }
        } catch(Exception ex){
            System.out.println("Error reading order.txt "+ex);
        }
        loginPage = new LoginPage();
        Assignment.loginPage.setVisible(true);
    }
}
