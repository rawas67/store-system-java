/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import static assignment.Assignment.courierArr;
import static assignment.Assignment.customerArr;
import static assignment.Assignment.orderArr;
import assignment.people.Courier;
import assignment.people.Customer;
import assignment.people.RoleEnum;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

/**
 *
 * @author asus
 */
public class CourierPage extends JFrame implements ActionListener {
    
    private static Courier currentLogin;
    
    public static JPanel mainPanel;
    
    public static Button backBtn;
    
    public static Label editAccountTitleLabel, editOrderTitleLabel, listOrderTitleLabel, ratingTitleLabel;
    
    public static JPanel editPanel;
    public static Label IDLabel, IDLabel2, nameLabel, telephoneLabel, addressLabel, roleLabel, roleLabel2, passwordLabel;
    public static TextField nameTextField, telephoneTextField, addressTextField, passwordTextField;
    public static Button restoreBtn, changeBtn;

    public static JPanel viewRatingPanel;
    public static Label amountRatingLabel, amountRatingLabel2;
    public static Button refreshRatingBtn;
    DefaultTableModel tableModel3;
    public static JTable ratingTable;
    public static JScrollPane ratingScrollPane;
    String[] ratingColumnNames = {"ORDER_ID", "Rating", "Feedback"};
    
    public static Button refreshBtn;
    DefaultTableModel tableModel2;
    public static JPanel orderTablePanel;
    public static JTable orderTable;
    public static JScrollPane orderScrollPane;
    String[] orderColumnNames = {"ORDER_ID", "CourierID", "CustomerID", "Charge", "Departure", "Destination", "StartTime", "EndTime", "Rating", "Feedback"};
    
    public static JPanel editOrderPanel;
    public static Label orderIDLabel, assignedCourierLabel, owningCustomerLabel, chargeLabel, departureLabel, destinationLabel, startLabel, endLabel, ratingLabel, feedbackLabel, paymentLabel, statusLabel;
    public static Label orderIDLabel2, assignedCourierLabel2, owningCustomerLabel2, chargeLabel2, departureLabel2, destinationLabel2, startLabel2;
    public static TextField orderIDTextField, endTextField, feedbackTextField, paymentTextField;
    public static Button completeOrderBtn, nowBtn, printOrderBtn;
    
    public CourierPage(){
        this.setSize(1300,700);
        setLocation(300,200);
        //close the GUI and stop the system
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Font f = new Font(Font.SANS_SERIF,Font.BOLD,16);
        GridBagConstraints c;
        
        backBtn = new Button("Back to Login");
        backBtn.addActionListener(this);
                       
        editPanel = new JPanel();
        editPanel.setLayout(new GridBagLayout());
        
        editAccountTitleLabel =  new Label("Profile Management");
        editAccountTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 0;
        c.gridwidth = 2;
        editPanel.add(editAccountTitleLabel, c );
        
        IDLabel = new Label("ID :");
        IDLabel2 = new Label("                   ");
        nameLabel = new Label("Name :");
        telephoneLabel = new Label("Telephone :");
        addressLabel = new Label("Address :");
        roleLabel = new Label("Role :");
        roleLabel2 = new Label("                   ");
        passwordLabel = new Label("Password :");
        
        nameTextField = new TextField(15); 
        telephoneTextField = new TextField(15);
        addressTextField = new TextField(15);
        passwordTextField = new TextField(15);
        
        restoreBtn = new Button("Restore");
        restoreBtn.addActionListener(this);
        changeBtn = new Button("  Set  ");
        changeBtn.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        editPanel.add(IDLabel, c);
        c.gridx = 1;
        c.gridy = 2;
        editPanel.add(nameLabel, c);
        c.gridx = 1;
        c.gridy = 3;
        editPanel.add(telephoneLabel, c);
        c.gridx = 1;
        c.gridy = 4;
        editPanel.add(addressLabel, c);
        c.gridx = 1;
        c.gridy = 5;
        editPanel.add(roleLabel, c);
        c.gridx = 1;
        c.gridy = 6;
        editPanel.add(passwordLabel, c);
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;
        editPanel.add(IDLabel2, c);
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        editPanel.add(nameTextField, c);
        c.gridx = 2;
        c.gridy = 3;
        c.gridwidth = 2;
        editPanel.add(telephoneTextField, c);
        c.gridx = 2;
        c.gridy = 4;
        c.gridwidth = 2;
        editPanel.add(addressTextField, c);
        c.gridx = 2;
        c.gridy = 5;
        c.gridwidth = 2;
        editPanel.add(roleLabel2, c);
        c.gridx = 2;
        c.gridy = 6;
        c.gridwidth = 2;
        editPanel.add(passwordTextField, c);
        
        c.gridx = 1;
        c.gridy = 7;
        editPanel.add(restoreBtn, c);
        c.gridx = 2;
        c.gridy = 7;
        editPanel.add(changeBtn, c);
        
        refreshBtn = new Button("Refresh");
        refreshBtn.addActionListener(this);
        
        viewRatingPanel = new JPanel();
        viewRatingPanel.setLayout(new GridBagLayout());
        
        ratingTitleLabel =  new Label("Feedback and Rating");
        ratingTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 2;
        viewRatingPanel.add(ratingTitleLabel, c );
        
        amountRatingLabel =  new Label("Rating total : ");
        amountRatingLabel2 =  new Label("                         ");
        
        refreshRatingBtn = new Button("Refresh");
        refreshRatingBtn.addActionListener(this);
        
        tableModel3 = new DefaultTableModel(ratingColumnNames, 0);
        ratingTable = new JTable(tableModel3) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        
        for(int i=0; i<10; i++){
            Object[] objs = {"","",""};
            tableModel3.addRow(objs);
        }
        
        ratingTable.getTableHeader().setMinimumSize(new Dimension(400,15));
        ratingTable.setMinimumSize(new Dimension(400,400));
        ratingTable.setCellSelectionEnabled(false);
        ratingScrollPane = new JScrollPane(orderTable);
        ratingScrollPane.setMinimumSize(new Dimension(400,500));
        ratingScrollPane.setMaximumSize(new Dimension(400,500));
        
        TableColumn column = null;
        for (int i = 0; i < 2; i++) {
            column = ratingTable.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(50);
            } else if (i == 1) {
                column.setPreferredWidth(50);
            } else {
                column.setPreferredWidth(300);    
            }
        }
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 4;
        viewRatingPanel.add(refreshRatingBtn,c);
        
        c.gridx = 1;
        c.gridy = 1;
        viewRatingPanel.add(amountRatingLabel,c);
        c.gridx = 2;
        c.gridy = 1;
        viewRatingPanel.add(amountRatingLabel2,c);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 3;
        viewRatingPanel.add(ratingTable.getTableHeader(),c);
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 3;
        viewRatingPanel.add(ratingTable,c);
        
        
        orderTablePanel = new JPanel();
        orderTablePanel.setLayout(new GridBagLayout());
        
        listOrderTitleLabel =  new Label("Assigned Order");
        listOrderTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        orderTablePanel.add(listOrderTitleLabel, c );
        
        tableModel2 = new DefaultTableModel(orderColumnNames, 0);
        orderTable = new JTable(tableModel2) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        for(int i=0; i<10; i++){
            Object[] objs = {"","","","","","","","","",""};
            tableModel2.addRow(objs);
        }
        
        orderTable.getTableHeader().setMinimumSize(new Dimension(750,15));
        orderTable.setMinimumSize(new Dimension(750,400));
        orderTable.setCellSelectionEnabled(false);
        orderScrollPane = new JScrollPane(orderTable);
        orderScrollPane.setMinimumSize(new Dimension(750,500));
        orderScrollPane.setMaximumSize(new Dimension(750,500));
        
        column = null;
        for (int i = 0; i < 5; i++) {
            column = orderTable.getColumnModel().getColumn(i);
            if (i == 0 || i == 3) {
                column.setPreferredWidth(55);
            } else if (i == 4 || i == 5) {
                column.setPreferredWidth(100);
            } else {
                column.setPreferredWidth(75);    
            }
        }
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        orderTablePanel.add(refreshBtn,c);
        c.gridx = 0;
        c.gridy = 1;
        c.gridwidth = 2;
        orderTablePanel.add(orderTable.getTableHeader(),c);
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 2;
        c.gridwidth = 2;
        orderTablePanel.add(orderTable,c);
        
                
        editOrderPanel = new JPanel();
        editOrderPanel.setLayout(new GridBagLayout());
        
        editOrderTitleLabel =  new Label("Complete Order");
        editOrderTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 3;
        c.gridy = 0;
        editOrderPanel.add(editOrderTitleLabel, c );
        
        orderIDLabel = new Label("Order ID :");
        assignedCourierLabel = new Label("CourierName : ");
        owningCustomerLabel = new Label("CustomerName : ");
        chargeLabel = new Label("Charge : ");
        departureLabel = new Label("Departure : ");
        destinationLabel = new Label("Destination : ");
        startLabel = new Label("Start Time : ");
        endLabel = new Label("End Time : ");
        ratingLabel = new Label("Rating : ");
        feedbackLabel = new Label("Feedback : ");
        paymentLabel = new Label("Payment amount : ");
        statusLabel = new Label("Status : ");
        
        orderIDTextField = new TextField(20);
        orderIDTextField.addActionListener(this);
        assignedCourierLabel2 = new Label("                                                    ");
        owningCustomerLabel2 = new Label("                                                    ");
        chargeLabel2 = new Label("                                                    ");
        departureLabel2 = new Label("                                                    ");
        destinationLabel2 = new Label("                                                    ");
        startLabel2 = new Label("                                                    ");
        endTextField = new TextField(14);
        feedbackTextField = new TextField(20);
        paymentTextField = new TextField(20);
        
        nowBtn = new Button("Now");
        nowBtn.addActionListener(this);
        completeOrderBtn = new Button("Finish this order");
        completeOrderBtn.addActionListener(this);
        printOrderBtn = new Button("Set");
        printOrderBtn.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        editOrderPanel.add(orderIDLabel, c);
        c.gridx = 0;
        c.gridy = 2;
        editOrderPanel.add(assignedCourierLabel, c);
        c.gridx = 0;
        c.gridy = 3;
        editOrderPanel.add(owningCustomerLabel, c);
        c.gridx = 0;
        c.gridy = 4;
        editOrderPanel.add(chargeLabel, c);
        c.gridx = 0;
        c.gridy = 5;
        editOrderPanel.add(departureLabel, c);
        c.gridx = 0;
        c.gridy = 6;
        editOrderPanel.add(destinationLabel, c);
        
        c.gridx = 3;
        c.gridy = 1;
        editOrderPanel.add(startLabel, c);
        c.gridx = 3;
        c.gridy = 2;
        editOrderPanel.add(endLabel, c);
        c.gridx = 3;
        c.gridy = 3;
        editOrderPanel.add(feedbackLabel, c);
        c.gridx = 3;
        c.gridy = 4;
        editOrderPanel.add(paymentLabel, c);
        c.gridx = 3;
        c.gridy = 5;
        editOrderPanel.add(statusLabel, c);
        
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 2;
        editOrderPanel.add(orderIDTextField, c);
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        editOrderPanel.add(assignedCourierLabel2, c);
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 2;
        editOrderPanel.add(owningCustomerLabel2, c);
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 2;
        editOrderPanel.add(chargeLabel2, c);
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 2;
        editOrderPanel.add(departureLabel2, c);
        c.gridx = 1;
        c.gridy = 6;
        c.gridwidth = 2;
        editOrderPanel.add(destinationLabel2, c);
        
        c.gridx = 4;
        c.gridy = 1;
        c.gridwidth = 2;
        editOrderPanel.add(startLabel2, c);
        c.gridx = 4;
        c.gridy = 2;
        c.gridwidth = 1;
        editOrderPanel.add(endTextField, c);
        c.gridx = 4;
        c.gridy = 3;
        c.gridwidth = 2;
        editOrderPanel.add(feedbackTextField, c);
        c.gridx = 4;
        c.gridy = 4;
        c.gridwidth = 2;
        editOrderPanel.add(paymentTextField, c);
        
        c.gridx = 5;
        c.gridy = 2;
        c.gridwidth = 1;
        editOrderPanel.add(nowBtn, c);
        c.gridx = 4;
        c.gridy = 5;
        c.gridwidth = 2;
        editOrderPanel.add(completeOrderBtn, c);
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        mainPanel.add(backBtn, c);
        c.gridx = 1;
        c.gridy = 1;
        mainPanel.add(editPanel, c);
        c.gridx = 1;
        c.gridy = 2;
        c.gridheight = 2;
        mainPanel.add(viewRatingPanel, c);

        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 2;
        mainPanel.add(editOrderPanel, c);
        c.gridx = 2;
        c.gridy = 2;
        //mainPanel.add(searchOrderPanel, c);
        c.gridx = 2;
        c.gridy = 3;
        mainPanel.add(orderTablePanel, c);
        
        add(mainPanel);
    }
    
    public void setCurrentLogin(Courier courier) {
        this.currentLogin = currentLogin;
    }
    public Courier getCurrentLogin() {
        return currentLogin;
    }
    
    public void clearPersonTextField() {
        nameTextField.setText("");
        telephoneTextField.setText("");
        addressTextField.setText("");
        passwordTextField.setText("");
    }
    
    public void clearOrderTextField(){
        orderIDTextField.setText("");
        assignedCourierLabel2.setText("");
        owningCustomerLabel2.setText("");
        chargeLabel2.setText("");
        departureLabel2.setText("");
        destinationLabel2.setText("");
        startLabel2.setText("");
        endTextField.setText("");
        feedbackTextField.setText("");
        paymentTextField.setText("");
    }
    
    public void loadProfileTextField(Courier currentLogin){
        this.currentLogin = currentLogin;
        IDLabel2.setText(String.valueOf(currentLogin.getId()));
        roleLabel2.setText(currentLogin.getRole().toString());
        nameTextField.setText(currentLogin.getName());
        telephoneTextField.setText(String.valueOf(currentLogin.getTelephone()));
        addressTextField.setText(currentLogin.getAddress());
        passwordTextField.setText(currentLogin.getPassword());
    };
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == restoreBtn){
            loadProfileTextField(currentLogin);
        }
        if(e.getSource() == changeBtn){
            int  ID = currentLogin.getId();
            String name = null;
            int telephone = 0;
            String address = null;
            RoleEnum role = currentLogin.getRole();
            String password = null;
            try{
                if(!nameTextField.getText().equals("")&&
                   !telephoneTextField.getText().equals("")&&
                        !addressTextField.getText().equals("")){
                        //remove old data
                        try{Assignment.courierArr.remove(Assignment.findCourierByID(ID,Assignment.courierArr));} catch (Exception Ex) {}

                        name = nameTextField.getText();
                        telephone = Integer.parseInt(telephoneTextField.getText());
                        address = addressTextField.getText();
                        if(!passwordTextField.getText().equals("")){
                            password=passwordTextField.getText();
                            Courier courier = new Courier(ID, name, telephone, address, role, password);
                            Assignment.courierArr.add(courier);
                            JOptionPane.showMessageDialog(this,"Profile updated");
                        } else {
                            JOptionPane.showMessageDialog(this,"Employee must have password");
                        }
                } else {
                    JOptionPane.showMessageDialog(this,"ID, name, telephone, address, role must be filled");
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"Error! Please try again");
            }
        }
        if(e.getSource() == refreshRatingBtn){
            tableModel3.removeRow(9);
            tableModel3.removeRow(8);
            tableModel3.removeRow(7);
            tableModel3.removeRow(6);
            tableModel3.removeRow(5);
            tableModel3.removeRow(4);
            tableModel3.removeRow(3);
            tableModel3.removeRow(2);
            tableModel3.removeRow(1);
            tableModel3.removeRow(0);
            int i=0;
            int ratingTotal = 0;
            for(int i2 = Assignment.orderArr.size()-1; i2 >=0 ; i2--){
                Order order = Assignment.orderArr.get(i2);
                int ORDER_ID = -1;
                ORDER_ID = currentLogin.getId();
                try{
                    if(order.getAssignedCourier().getId() == currentLogin.getId()) {
                        if(i != 9 && i<10){
                            Object[] objs = {order.getOrderId(),String.valueOf(order.getRating().getValue()),order.getFeedback()};
                            tableModel3.addRow(objs);
                            i++;
                        } else if(i<10) {
                            Object[] objs = {"+","+","+","+","+","+","+","+","+","+","+"};
                            tableModel3.addRow(objs);
                            i++;
                        }
                        ratingTotal = ratingTotal+order.getRating().getValue();
                    }
                } catch(Exception Ex) {}
            }
            amountRatingLabel2.setText(String.valueOf(ratingTotal));
            for(; i<10; i++){
                Object[] objs = {"","","","","","","","","",""};
                tableModel3.addRow(objs);
            }
            
        }
        if(e.getSource() == refreshBtn){
            tableModel2.removeRow(9);
            tableModel2.removeRow(8);
            tableModel2.removeRow(7);
            tableModel2.removeRow(6);
            tableModel2.removeRow(5);
            tableModel2.removeRow(4);
            tableModel2.removeRow(3);
            tableModel2.removeRow(2);
            tableModel2.removeRow(1);
            tableModel2.removeRow(0);
            int i=0;
            for(Order order : Assignment.orderArr){
                try{
                    if(order.getAssignedCourier().getId() == currentLogin.getId() && order.getStatus().equals(StatusEnum.OnTheWay)) {
                        if(i != 9 && i<10){
                            Object[] objs = {order.getOrderId(),order.getAssignedCourier().getId(),order.getOwningCustomer().getId(),order.getCharge(),order.getDepartureAddress(),order.getDestinationAddress(),order.getSTART_TIME(),order.getEndTime(),order.getRating().toString(),order.getFeedback()};
                            tableModel2.addRow(objs);
                            i++;
                        } else if(i<10) {
                            Object[] objs = {"+","+","+","+","+","+","+","+","+","+"};
                            tableModel2.addRow(objs);
                            i++;
                        }
                    }
                } catch(Exception Ex) {}
            }
            for(; i<10; i++){
                Object[] objs = {"","","","","","","","","",""};
                tableModel2.addRow(objs);
            }
        }
        if(e.getSource() == orderIDTextField){
            try{
                int ORDER_ID = Integer.parseInt(orderIDTextField.getText());
                Order order = Assignment.findOrderByID(ORDER_ID, Assignment.orderArr);
                if(order == null){
                    JOptionPane.showMessageDialog(this,"Order not found!");
                    throw new Exception("");
                }
                if(order.getAssignedCourier().getId() != currentLogin.getId()){
                    JOptionPane.showMessageDialog(this,"Order did not belong to you!");
                    throw new Exception("");
                }
                if(!order.getStatus().equals(StatusEnum.OnTheWay)){
                    JOptionPane.showMessageDialog(this,"Order are "+order.getStatus().toString());
                    throw new Exception("");
                }
                assignedCourierLabel2.setText(order.getAssignedCourier().getName());
                owningCustomerLabel2.setText(order.getOwningCustomer().getName());
                chargeLabel2.setText(String.valueOf(order.getCharge()));
                departureLabel2.setText(order.getDepartureAddress());
                destinationLabel2.setText(order.getDestinationAddress());
                String str = order.getSTART_TIME().toString();
                str = str.substring(0, 16);
                str = str.replace("T"," ");
                startLabel2.setText(str);
                str = str.substring(0, 16);
                str = order.getEndTime().toString();
                str = str.replace("T"," ");
                endTextField.setText(str);
                feedbackTextField.setText(order.getFeedback());
            } catch (Exception Ex) {}
        }
        if(e.getSource() == completeOrderBtn){
            int ORDER_ID = 0;
            try{
                if(!orderIDTextField.getText().equals("")){
                    ORDER_ID = Integer.parseInt(orderIDTextField.getText());
                    if(ORDER_ID > 0 &&
                    !endTextField.getText().equals("") && 
                    !paymentTextField.getText().equals("") ){
                        //get reference and remove old data 
                        Order oldOrder = null;
                        try{
                            oldOrder = Assignment.findOrderByID(ORDER_ID, Assignment.orderArr);
                            Assignment.orderArr.remove(Assignment.findOrderByID(ORDER_ID, Assignment.orderArr));
                        } catch (Exception Ex) {}
                        if(oldOrder.getCharge() - Integer.parseInt(paymentTextField.getText()) <= 0){
                            Courier assignedCourier = null;
                            assignedCourier = oldOrder.getAssignedCourier();

                            Customer owningCustomer = null;
                            owningCustomer = oldOrder.getOwningCustomer();

                            int charge = 0;
                            String departureAddress = oldOrder.getDepartureAddress();
                            String destinationAddress = oldOrder.getDestinationAddress();

                            LocalDateTime START_TIME = oldOrder.getSTART_TIME();

                            String str = endTextField.getText();
                            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                            LocalDateTime endTime = LocalDateTime.parse(str, formatter);

                            RatingEnum rating = oldOrder.getRating();

                            String feedback = feedbackTextField.getText();

                            StatusEnum status = StatusEnum.Finished;

                            Order order = new Order(ORDER_ID, assignedCourier, owningCustomer, charge, departureAddress, destinationAddress, START_TIME, endTime, rating, feedback, status);
                            orderArr.add(order);
                            
                            int returnAmount = Integer.parseInt(paymentTextField.getText()) - oldOrder.getCharge();
                            if(returnAmount > 0){
                                JOptionPane.showMessageDialog(this,"Order completed, please return "+returnAmount+" RM to customer");
                            } else {
                                JOptionPane.showMessageDialog(this,"Order completed");
                            }
                        } else {
                            JOptionPane.showMessageDialog(this,"Payment amount cannot be less than order charge");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this,"Error! Please try again");
                    }
                } else {
                    JOptionPane.showMessageDialog(this,"ID are required");
                }
            } catch (Exception Ex) {}
        }
        if(e.getSource() == nowBtn){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime nowTime = LocalDateTime.now();
            String str = nowTime.toString().replace("T", " ");
            endTextField.setText(str);
        }
        if(e.getSource() == backBtn){
            this.setVisible(false);
            Assignment.loginPage.setVisible(true);
        }
    }
}


