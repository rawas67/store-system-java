/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author asus
 */
public enum StatusEnum {
    InProgress(0),OnTheWay(1),Finished(2);
    private int value;
    private StatusEnum(int x){
        value = x;
    }
    public int getValue(){
        return value;
    }
}
