package assignment.people;

import assignment.Order;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public class Person extends MethodDirectory {
    private final int ID;
    private final String NAME;
    private int telephone;
    private String address;
    private RoleEnum role;
    
    public Person(int ID, String NAME, int telephone, String address, RoleEnum role) {
        this.ID = ID;
        this.NAME = NAME;
        this.telephone = telephone;
        this.address = address;
        this.role = role;
    }
    
    public int getId(){
        return ID;
    }
    
    public String getName(){
        return NAME;
    }
    
    public int getTelephone(){
        return this.telephone;
    }
    public void setTelephone(int telephone){
        this.telephone = telephone;
    }
    
    public String getAddress(){
        return address;
    }
    public void setAddress(String address){
        this.address = address;
    }
    
    public RoleEnum getRole(){
        return role;
    }

}
