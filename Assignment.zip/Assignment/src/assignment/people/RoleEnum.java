package assignment.people;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public enum RoleEnum {
    CUSTOMER(1),COURIER(2),MANAGER(3);
    private int value;
    private RoleEnum(int x){
        value = x;
    }
    public int getValue(){
        return value;
    }
}
