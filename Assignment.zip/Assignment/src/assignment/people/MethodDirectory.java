/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.people;

import assignment.Order;
import java.util.ArrayList;

/**
 *
 * @author asus
 */
public abstract class MethodDirectory {
    
    public static Customer findCustomerByID(int ID, ArrayList<Customer> customerArr) {
	    for (Customer customer : customerArr) {
	        if (customer.getId()==ID) {
                    return customer;
                }
	    }
	    return null;
    }
    public static Courier findCourierByID(int ID, ArrayList<Courier> courierArr) {
	    for (Courier courier : courierArr) {
	        if (courier.getId()==ID) {
                    return courier;
                }
	    }
	    return null;
    }
    public static Manager findManagerByID(int ID, ArrayList<Manager> managerArr) {
	    for (Manager manager : managerArr) {
	        if (manager.getId()==ID) {
                    return manager;
                }
	    }
	    return null;
    }
    
    public static int getNewID(ArrayList<Customer> customerArr, ArrayList<Courier> courierArr, ArrayList<Manager> managerArr){
        int id[] = new int[5];
        id[0] = 0;
        id[1] = 0;
        id[2] = 0;
        for(Customer customer : customerArr){ //get max customer.getId() from customerArr
            if(customer.getId() > id[0]){
                id[0] = customer.getId();
            } 
        }
        for(Courier courier : courierArr){  //get max courier.getId() from courierArr
            if(courier.getId() > id[0]){
                id[1] = courier.getId();
            } 
        }
        for(Manager manager : managerArr){  //get max manager.getId() from managerArr
            if(manager.getId() > id[0]){
                id[2] = manager.getId();
            } 
        }
        if(id[0]>id[1] && id[0]>id[2]){
            return id[0]+1;
        }
        if(id[1]>id[0] && id[1]>id[2]){
            return id[1]+1;
        } 
        if(id[2]>id[0] && id[2]>id[1]){
            return id[2]+1;
        }
        return 1;
    }
    
    public static int getNewID(ArrayList<Order> orderArr){
        int ORDER_ID = 0;
        for(Order order : orderArr){ //get max order.getOrderId() from orderArr
            if(order.getOrderId() > ORDER_ID){
                ORDER_ID = order.getOrderId();
            }
        }
        return ORDER_ID+1;
    }
    
     public static Order findOrderByID(int ORDER_ID, ArrayList<Order> orderArr) {
	    for (Order order : orderArr) {
	        if (order.getOrderId()==ORDER_ID) {
                    return order;
                }
	    }
	    return null;
    }
}
