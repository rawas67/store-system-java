/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.people;

/**
 *
 * @author asus
 */
public class Employee extends Person {
    
    private String password;
    
    public Employee(int ID, String NAME, int telephone, String address, RoleEnum role,String password) {
        super(ID, NAME, telephone, address, role);
        this.password = password;
    }
    
    public String getPassword(){
        return password;
    }
    
    public void setPassword(String password){
        this.password = password;
    }
    
}
