/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment.people;

import assignment.Order;
import java.util.ArrayList;

/**
 *
 * @author asus
 */
public class Customer extends Person{
    
    private ArrayList<Order> orderArr;
    
    public Customer(int ID, String NAME, int telephone, String address, RoleEnum role) {
        super(ID, NAME, telephone, address, role);
    }
    
    public ArrayList<Order> getOrder() {
        return orderArr;
    }
    
    public void setOrder(ArrayList<Order> orderArr) {
        this.orderArr = orderArr;
    }
    
}
