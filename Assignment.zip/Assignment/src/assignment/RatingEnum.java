/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

/**
 *
 * @author asus
 */
public enum RatingEnum {
    BAD(-1),NOT_YET_RATED(0),GOOD(1);
    private int value;
    private RatingEnum(int x){
        value = x;
    }
    public int getValue(){
        return value;
    }
}
