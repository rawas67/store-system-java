/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import static assignment.Assignment.courierArr;
import static assignment.Assignment.customerArr;
import static assignment.Assignment.orderArr;
import static assignment.ManagerPage.IDTextField;
import assignment.people.Courier;
import assignment.people.Customer;
import assignment.people.Manager;
import assignment.people.RoleEnum;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;


/**
 *
 * @author asus
 */
public class ManagerPage extends JFrame implements ActionListener {
    
    private static Manager currentLogin;
    
    public static JPanel mainPanel;
    
    public static Button backBtn;
    
    public static Label editAccountTitleLabel, editOrderTitleLabel, searchAccountTitleLabel, searchOrderTitleLabel, ratingTitleLabel, statTitleLabel;
    
    public static JPanel searchPanel;
    public static Label searchLabel;
    public static TextField searchTextField;
    public static Button searchBtn;
    
    DefaultTableModel tableModel;
    public static JPanel personTablePanel;
    public static JTable table;
    public static JScrollPane scrollPane;
    String[] columnNames = {"ID", "Name", "Telp", "Address", "Role", "Password"};
    
    public static JPanel editPanel;
    public static Label IDLabel, nameLabel, telephoneLabel, addressLabel, roleLabel, passwordLabel;
    public static TextField IDTextField, nameTextField, telephoneTextField, addressTextField, passwordTextField;
    public static JComboBox roleComboBox;
    public static Button newIDBtn, deleteBtn, changeBtn;
    
    public static JPanel viewRatingPanel;
    public static Label IDRatingLabel, amountRatingLabel, amountRatingLabel2;
    public static TextField IDRatingTextField;
    public static Button findRatingBtn;
    DefaultTableModel tableModel3;
    public static JTable ratingTable;
    public static JScrollPane ratingScrollPane;
    String[] ratingColumnNames = {"ORDER_ID", "Rating", "Feedback"};
    
    public static JPanel searchOrderPanel;
    public static Label searchOrderLabel;
    public static TextField searchOrderTextField;
    public static Button searchOrderBtn;
    
    public static JPanel statPanel;
    public static Label statCountLabel, statSatisfactionLabel;
    public static Label statTodayLabel, countTodayLabel, satisfactionTodayLabel;
    public static Label statSevenLabel, countSevenLabel, satisfactionSevenLabel;
    public static Label statPreviousWeekLabel, countPreviousWeekLabel, satisfactionPreviousWeekLabel;
    public static Label statThirtyLabel, countThirtyLabel, satisfactionThirtyLabel;
    public static Button refreshStatBtn;
    
    DefaultTableModel tableModel2;
    public static JPanel orderTablePanel;
    public static JTable orderTable;
    public static JScrollPane orderScrollPane;
    String[] orderColumnNames = {"ORDER_ID", "CourierID", "CustomerID", "Charge", "Departure", "Destination", "StartTime", "EndTime", "Rating", "Feedback", "Status"};
    
    public static JPanel editOrderPanel;
    public static Label orderIDLabel, assignedCourierLabel, owningCustomerLabel, chargeLabel, departureLabel, destinationLabel, startLabel, endLabel, ratingLabel, feedbackLabel, statusLabel;
    public static TextField orderIDTextField, assignedCourierIDTextField, owningCustomerIDTextField, chargeTextField, departureTextField, destinationTextField, startTextField, endTextField, feedbackTextField;
    public static JComboBox ratingComboBox, statusComboBox;
    public static Button newOrderIDBtn, deleteOrderBtn, nowBtn, nowBtn2, changeOrderBtn, printOrderBtn;
    
    public ManagerPage(){
        this.setSize(1300,700);
        setLocation(300,200);
        //close the GUI and stop the system
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Font f = new Font(Font.SANS_SERIF,Font.BOLD,16);
        GridBagConstraints c;
        
        backBtn = new Button("Back to Login");
        backBtn.addActionListener(this);
        
        searchPanel = new JPanel();
        searchPanel.setLayout(new FlowLayout());
        
        searchAccountTitleLabel =  new Label("Search Account");
        searchAccountTitleLabel.setFont(f);
        searchPanel.add(searchAccountTitleLabel);
        
        searchLabel =  new Label("Enter ID/ Name");
        searchTextField = new TextField(15);
        searchBtn = new Button("Search");
        searchBtn.addActionListener(this);
        
        searchPanel.add(searchLabel);
        searchPanel.add(searchTextField);
        searchPanel.add(searchBtn);
        
        personTablePanel = new JPanel();
        personTablePanel.setLayout(new BorderLayout());
        
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        for(int i=0; i<10; i++){
            Object[] objs = {"","","","","",""};
            tableModel.addRow(objs);
        }
        
        TableColumn column = null;
        scrollPane = new JScrollPane(table);
        for(int i = 0; i < 5; i++) {
            column = table.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(25);
            } else if (i == 4) {
                column.setPreferredWidth(75);
            } else {
                column.setPreferredWidth(50);    
            }
        }
        
        personTablePanel.add(table.getTableHeader(), BorderLayout.PAGE_START);
        personTablePanel.add(table, BorderLayout.CENTER);
        
        editPanel = new JPanel();
        editPanel.setLayout(new GridBagLayout());
        
        editAccountTitleLabel =  new Label("Account management");
        editAccountTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 0;
        c.gridwidth = 2;
        editPanel.add(editAccountTitleLabel, c);
        
        IDLabel = new Label("ID :");
        nameLabel = new Label("Name :");
        telephoneLabel = new Label("Telephone :");
        addressLabel = new Label("Address :");
        roleLabel = new Label("Role :");
        passwordLabel = new Label("Password :");
        IDTextField = new TextField(7); 
        IDTextField.addActionListener(this);
        
        nameTextField = new TextField(15); 
        telephoneTextField = new TextField(15);
        addressTextField = new TextField(15);
        passwordTextField = new TextField(15);
        
        String roleItem[] = {"CUSTOMER","COURIER","MANAGER"};
        roleComboBox = new JComboBox(roleItem);
        roleComboBox.setLightWeightPopupEnabled(false);
        
        newIDBtn = new Button("New ID");
        newIDBtn.addActionListener(this);
        deleteBtn = new Button("Delete");
        deleteBtn.addActionListener(this);
        changeBtn = new Button("Set");
        changeBtn.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        editPanel.add(IDLabel, c);
        c.gridx = 1;
        c.gridy = 2;
        editPanel.add(nameLabel, c);
        c.gridx = 1;
        c.gridy = 3;
        editPanel.add(telephoneLabel, c);
        c.gridx = 1;
        c.gridy = 4;
        editPanel.add(addressLabel, c);
        c.gridx = 1;
        c.gridy = 5;
        editPanel.add(roleLabel, c);
        c.gridx = 1;
        c.gridy = 6;
        editPanel.add(passwordLabel, c);
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 1;
        editPanel.add(IDTextField, c);
        c.gridx = 2;
        c.gridy = 2;
        c.gridwidth = 2;
        editPanel.add(nameTextField, c);
        c.gridx = 2;
        c.gridy = 3;
        c.gridwidth = 2;
        editPanel.add(telephoneTextField, c);
        c.gridx = 2;
        c.gridy = 4;
        c.gridwidth = 2;
        editPanel.add(addressTextField, c);
        
        c.gridx = 2;
        c.gridy = 6;
        c.gridwidth = 2;
        editPanel.add(passwordTextField, c);
        
        c.gridx = 3;
        c.gridy = 1;
        c.gridwidth = 1;
        editPanel.add(newIDBtn, c);
        c.gridx = 2;
        c.gridy = 7;
        editPanel.add(deleteBtn, c);
        c.gridx = 3;
        c.gridy = 7;
        editPanel.add(changeBtn, c);
        
        c.gridx = 2;
        c.gridy = 5;
        c.gridwidth = 2;
        editPanel.add(roleComboBox, c);
        
        viewRatingPanel = new JPanel();
        viewRatingPanel.setLayout(new GridBagLayout());
        
        ratingTitleLabel =  new Label("Feedback and rating");
        ratingTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 0;
        viewRatingPanel.add(ratingTitleLabel, c);
        
        IDRatingLabel =  new Label("Enter ID");
        IDRatingTextField = new TextField(15);
        amountRatingLabel =  new Label("Rating total : ");
        amountRatingLabel2 =  new Label("                         ");
        
        findRatingBtn = new Button("Get Rating");
        findRatingBtn.addActionListener(this);
        
        tableModel3 = new DefaultTableModel(ratingColumnNames, 0);
        ratingTable = new JTable(tableModel3) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        
        for(int i=0; i<10; i++){
            Object[] objs = {"","",""};
            tableModel3.addRow(objs);
        }
        
        ratingTable.getTableHeader().setMinimumSize(new Dimension(400,15));
        ratingTable.setMinimumSize(new Dimension(400,400));
        ratingTable.setCellSelectionEnabled(false);
        ratingScrollPane = new JScrollPane(orderTable);
        ratingScrollPane.setMinimumSize(new Dimension(400,500));
        ratingScrollPane.setMaximumSize(new Dimension(400,500));
        
        column = null;
        for (int i = 0; i < 2; i++) {
            column = ratingTable.getColumnModel().getColumn(i);
            if (i == 0) {
                column.setPreferredWidth(50);
            } else if (i == 1) {
                column.setPreferredWidth(50);
            } else {
                column.setPreferredWidth(300);    
            }
        }
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 1;
        viewRatingPanel.add(IDRatingLabel,c);
        c.gridx = 2;
        c.gridy = 1;
        viewRatingPanel.add(IDRatingTextField,c);
        c.gridx = 3;
        c.gridy = 1;
        viewRatingPanel.add(findRatingBtn,c);
        c.gridx = 1;
        c.gridy = 2;
        viewRatingPanel.add(amountRatingLabel,c);
        c.gridx = 2;
        c.gridy = 2;
        viewRatingPanel.add(amountRatingLabel2,c);
        
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 3;
        viewRatingPanel.add(ratingTable.getTableHeader(),c);
        c = new GridBagConstraints();
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 3;
        viewRatingPanel.add(ratingTable,c);
        
        statPanel = new JPanel();
        statPanel.setLayout(new GridBagLayout());
        
        statTitleLabel =  new Label("Reporting System");
        statTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 0;
        statPanel.add(statTitleLabel, c);
        
        statCountLabel =  new Label("Number of work done");
        statSatisfactionLabel =  new Label("Total rating");
        
        statTodayLabel =  new Label("Today : ");
        statSevenLabel =  new Label("Last 7 days : ");
        statPreviousWeekLabel =  new Label("Prev 7 days (-14 til -7) : ");
        statThirtyLabel =  new Label("Last 30 days : ");
        
        countTodayLabel =  new Label("          ");
        countSevenLabel =  new Label("          ");
        countPreviousWeekLabel =  new Label("          ");
        countThirtyLabel =  new Label("          ");
        
        satisfactionTodayLabel =  new Label("          ");
        satisfactionSevenLabel =  new Label("          ");
        satisfactionPreviousWeekLabel =  new Label("          ");
        satisfactionThirtyLabel =  new Label("          ");
        
        refreshStatBtn = new Button("Refresh");
        refreshStatBtn.addActionListener(this);
        
        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 1;
        statPanel.add(statCountLabel,c);
        c.gridx = 3;
        c.gridy = 1;
        statPanel.add(statSatisfactionLabel,c);
        
        c.gridx = 1;
        c.gridy = 2;
        statPanel.add(statTodayLabel,c);
        c.gridx = 1;
        c.gridy = 3;
        statPanel.add(statSevenLabel,c);
        c.gridx = 1;
        c.gridy = 4;
        statPanel.add(statPreviousWeekLabel,c);
        c.gridx = 1;
        c.gridy = 5;
        statPanel.add(statThirtyLabel,c);
        
        c.gridx = 2;
        c.gridy = 2;
        statPanel.add(countTodayLabel,c);
        c.gridx = 2;
        c.gridy = 3;
        statPanel.add(countSevenLabel,c);
        c.gridx = 2;
        c.gridy = 4;
        statPanel.add(countPreviousWeekLabel,c);
        c.gridx = 2;
        c.gridy = 5;
        statPanel.add(countThirtyLabel,c);
        
        c.gridx = 3;
        c.gridy = 2;
        statPanel.add(satisfactionTodayLabel,c);
        c.gridx = 3;
        c.gridy = 3;
        statPanel.add(satisfactionSevenLabel,c);
        c.gridx = 3;
        c.gridy = 4;
        statPanel.add(satisfactionPreviousWeekLabel,c);
        c.gridx = 3;
        c.gridy = 5;
        statPanel.add(satisfactionThirtyLabel,c);
        
        c.gridx = 1;
        c.gridy = 1;
        statPanel.add(refreshStatBtn,c);
        
        searchOrderPanel = new JPanel();
        searchOrderPanel.setLayout(new FlowLayout());
        
        searchOrderTitleLabel =  new Label("Search Order");
        searchOrderTitleLabel.setFont(f);
        searchOrderPanel.add(searchOrderTitleLabel);
        
        searchOrderLabel =  new Label("Enter Name/ OrderID");
        searchOrderTextField = new TextField(15);
        searchOrderBtn = new Button("Search");
        searchOrderBtn.addActionListener(this);
        
        searchOrderPanel.add(searchOrderLabel);
        searchOrderPanel.add(searchOrderTextField);
        searchOrderPanel.add(searchOrderBtn);
        
        orderTablePanel = new JPanel();
        orderTablePanel.setLayout(new GridBagLayout());
        
        tableModel2 = new DefaultTableModel(orderColumnNames, 0);
        orderTable = new JTable(tableModel2) {
            @Override
            public boolean isCellEditable(int row, int column) {
                //all cells false
                return false;
            }
        };
        for(int i=0; i<10; i++){
            Object[] objs = {"","","","","","","","","","",""};
            tableModel2.addRow(objs);
        }
        
        orderTable.getTableHeader().setMinimumSize(new Dimension(1150,15));
        orderTable.setMinimumSize(new Dimension(1150,400));
        orderTable.setCellSelectionEnabled(false);
        orderScrollPane = new JScrollPane(orderTable);
        orderScrollPane.setMinimumSize(new Dimension(1150,500));
        orderScrollPane.setMaximumSize(new Dimension(1150,500));
        
        column = null;
        for (int i = 0; i < 11; i++) {
            column = orderTable.getColumnModel().getColumn(i);
            if (i == 4) {
                column.setPreferredWidth(150);
            } else if (i == 5) {
                column.setPreferredWidth(150);
            } else {
                column.setPreferredWidth(75);    
            }
        }
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        orderTablePanel.add(orderTable.getTableHeader(),c);
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 2;
        orderTablePanel.add(orderTable,c);
        
        editOrderPanel = new JPanel();
        editOrderPanel.setLayout(new GridBagLayout());
        
        editOrderTitleLabel =  new Label("Order management system");
        editOrderTitleLabel.setFont(f);
        c = new GridBagConstraints();
        c.gridx = 2;
        c.gridy = 0;
        c.gridwidth = 2;
        editOrderPanel.add(editOrderTitleLabel, c);
        
        orderIDLabel = new Label("Order ID :");
        assignedCourierLabel = new Label("CourierID : ");
        owningCustomerLabel = new Label("CustomerID : ");
        chargeLabel = new Label("Charge : ");
        departureLabel = new Label("Departure : ");
        destinationLabel = new Label("Destination : ");
        startLabel = new Label("Start Time : ");
        endLabel = new Label("End Time : ");
        ratingLabel = new Label("Rating : ");
        feedbackLabel = new Label("Feedback : ");
        statusLabel = new Label("Status : ");
        
        orderIDTextField = new TextField(5);
        orderIDTextField.addActionListener(this);
        assignedCourierIDTextField = new TextField(20);
        owningCustomerIDTextField = new TextField(20);
        chargeTextField = new TextField(20);
        departureTextField = new TextField(20);
        destinationTextField = new TextField(20);
        startTextField = new TextField(14);
        endTextField = new TextField(14);
        feedbackTextField = new TextField(20);
        
        String ratingItem[] = {"BAD","NOT_YET_RATED","GOOD"};
        ratingComboBox = new JComboBox(ratingItem);
        ratingComboBox.setSelectedItem("NOT_YET_RATED");
        ratingComboBox.setLightWeightPopupEnabled(false);
        String statusItem[] = {"InProgress","OnTheWay","Finished"};
        statusComboBox = new JComboBox(statusItem);
        statusComboBox.setLightWeightPopupEnabled(false);
        
        newOrderIDBtn = new Button("New ORDER_ID");
        newOrderIDBtn.addActionListener(this);
        deleteOrderBtn = new Button("Delete");
        deleteOrderBtn.addActionListener(this);
        nowBtn = new Button("Now");
        nowBtn.addActionListener(this);
        nowBtn2 = new Button("Now");
        nowBtn2.addActionListener(this);
        changeOrderBtn = new Button("    Set    ");
        changeOrderBtn.addActionListener(this);
        printOrderBtn = new Button("  Set & Print  ");
        printOrderBtn.addActionListener(this);
                
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        editOrderPanel.add(orderIDLabel, c);
        c.gridx = 0;
        c.gridy = 2;
        editOrderPanel.add(assignedCourierLabel, c);
        c.gridx = 0;
        c.gridy = 3;
        editOrderPanel.add(owningCustomerLabel, c);
        c.gridx = 0;
        c.gridy = 4;
        editOrderPanel.add(chargeLabel, c);
        c.gridx = 0;
        c.gridy = 5;
        editOrderPanel.add(departureLabel, c);
        c.gridx = 0;
        c.gridy = 6;
        editOrderPanel.add(destinationLabel, c);
        
        c.gridx = 3;
        c.gridy = 1;
        editOrderPanel.add(startLabel, c);
        c.gridx = 3;
        c.gridy = 2;
        editOrderPanel.add(endLabel, c);
        c.gridx = 3;
        c.gridy = 3;
        editOrderPanel.add(ratingLabel, c);
        c.gridx = 3;
        c.gridy = 4;
        editOrderPanel.add(feedbackLabel, c);
        c.gridx = 3;
        c.gridy = 5;
        editOrderPanel.add(statusLabel, c);
        
        c.gridx = 1;
        c.gridy = 1;
        c.gridwidth = 1;
        editOrderPanel.add(orderIDTextField, c);
        c.gridx = 1;
        c.gridy = 2;
        c.gridwidth = 2;
        editOrderPanel.add(assignedCourierIDTextField, c);
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 2;
        editOrderPanel.add(owningCustomerIDTextField, c);
        c.gridx = 1;
        c.gridy = 4;
        c.gridwidth = 2;
        editOrderPanel.add(chargeTextField, c);
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 2;
        editOrderPanel.add(departureTextField, c);
        c.gridx = 1;
        c.gridy = 6;
        c.gridwidth = 2;
        editOrderPanel.add(destinationTextField, c);
        
        c.gridx = 4;
        c.gridy = 1;
        c.gridwidth = 1;
        editOrderPanel.add(startTextField, c);
        c.gridx = 4;
        c.gridy = 2;
        c.gridwidth = 1;
        editOrderPanel.add(endTextField, c);
        
        c.gridx = 4;
        c.gridy = 4;
        c.gridwidth = 2;
        editOrderPanel.add(feedbackTextField, c);
        
        
        c.gridx = 2;
        c.gridy = 1;
        c.gridwidth = 1;
        editOrderPanel.add(newOrderIDBtn, c);
        c.gridx = 5;
        c.gridy = 1;
        c.gridwidth = 1;
        editOrderPanel.add(nowBtn, c);
        c.gridx = 5;
        c.gridy = 2;
        c.gridwidth = 1;
        editOrderPanel.add(nowBtn2, c);
        c.gridx = 3;
        c.gridy = 6;
        c.gridwidth = 1;
        editOrderPanel.add(deleteOrderBtn, c);
        c.gridx = 4;
        c.gridy = 6;
        c.gridwidth = 1;
        editOrderPanel.add(changeOrderBtn, c);
        c.gridx = 5;
        c.gridy = 6;
        c.gridwidth = 1;
        editOrderPanel.add(printOrderBtn, c);
        
        
        c.gridx = 4;
        c.gridy = 5;
        c.gridwidth = 2;
        editOrderPanel.add(statusComboBox, c);
        c.gridx = 4;
        c.gridy = 3;
        c.gridwidth = 2;
        editOrderPanel.add(ratingComboBox, c);
        
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridBagLayout());
        
        c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 1;
        mainPanel.add(backBtn, c);
        
        
        c.gridx = 2;
        c.gridy = 1;
        mainPanel.add(searchPanel, c);
        c.gridx = 2;
        c.gridy = 2;
        mainPanel.add(personTablePanel, c);
        
        c.gridx = 1;
        c.gridy = 2;
        mainPanel.add(editPanel, c);
        
        c.gridx = 3;
        c.gridy = 1;
        c.gridheight = 2;
        mainPanel.add(viewRatingPanel, c);

        c = new GridBagConstraints();
        c.gridx = 3;
        c.gridy = 3;
        mainPanel.add(statPanel, c);
        
        c.gridx = 2;
        c.gridy = 4;
        mainPanel.add(searchOrderPanel, c);
        c.gridx = 1;
        c.gridy = 5;
        c.gridwidth = 3;
        mainPanel.add(orderTablePanel, c);
        
        c.gridx = 1;
        c.gridy = 3;
        c.gridwidth = 2;
        mainPanel.add(editOrderPanel, c);
        
        add(mainPanel);
    }
    
    public void setCurrentLogin(Manager currentLogin) {
        this.currentLogin = currentLogin;
    }
    public Manager getCurrentLogin() {
        return currentLogin;
    }
    
    public void clearPersonTextField() {
        IDTextField.setText("");
        nameTextField.setText("");
        telephoneTextField.setText("");
        addressTextField.setText("");
        roleComboBox.setSelectedItem("CUSTOMER");
        passwordTextField.setText("");
    }
    
    public void clearOrderTextField(){
        orderIDTextField.setText("");
        assignedCourierIDTextField.setText("");
        owningCustomerIDTextField.setText("");
        chargeTextField.setText("");
        departureTextField.setText("");
        destinationTextField.setText("");
        startTextField.setText("");
        endTextField.setText("");
        ratingComboBox.setSelectedItem("NOT_YET_RATED");
        feedbackTextField.setText("");
        statusComboBox.setSelectedItem("InProgress");
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == refreshStatBtn){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            String str = LocalDateTime.now().format(formatter);
            LocalDateTime now = LocalDateTime.parse(str, formatter);
            int todayCount=0;
            int todayReview=0;
            int sevenCount=0;
            int sevenReview=0;
            int previousWeekCount=0;
            int previousWeekReview=0;
            int lastThirtyCount=0;
            int lastThirtyReview=0;
            
            for(Order order : Assignment.orderArr){
                if(order.getEndTime().isAfter(now.minusDays(1)) && order.getStatus().equals(StatusEnum.Finished)){ //Last 24 hour
                    todayCount = todayCount+1;
                    todayReview = todayReview+order.getRating().getValue();
                }
                if(order.getEndTime().isAfter(now.minusDays(7)) && order.getStatus().equals(StatusEnum.Finished)){ //Last 7 days
                    sevenCount = sevenCount+1;
                    sevenReview = sevenReview+order.getRating().getValue();
                }
                if(order.getEndTime().isAfter(now.minusDays(14)) &&
                    order.getEndTime().isBefore(now.minusDays(7)) && 
                    order.getStatus().equals(StatusEnum.Finished)){ //Last 14 - 7 days
                    
                    previousWeekCount = previousWeekCount+1;
                    previousWeekReview = previousWeekReview+order.getRating().getValue();
                }
                if(order.getEndTime().isAfter(now.minusDays(30)) && order.getStatus().equals(StatusEnum.Finished)){ //Last 30 days
                    lastThirtyCount = lastThirtyCount+1;
                    lastThirtyReview = lastThirtyReview+order.getRating().getValue();
                }
            }
            countTodayLabel.setText(String.valueOf(todayCount));
            satisfactionTodayLabel.setText(String.valueOf(todayReview));
            
            countSevenLabel.setText(String.valueOf(sevenCount));
            satisfactionSevenLabel.setText(String.valueOf(sevenReview));
            
            countPreviousWeekLabel.setText(String.valueOf(previousWeekCount));
            satisfactionPreviousWeekLabel.setText(String.valueOf(previousWeekReview));
            
            countThirtyLabel.setText(String.valueOf(lastThirtyCount));
            satisfactionThirtyLabel.setText(String.valueOf(lastThirtyReview));
        }
        if(e.getSource() == IDTextField){
            try{
                int ID = Integer.valueOf(IDTextField.getText());
                Customer customer = Assignment.findCustomerByID(ID, Assignment.customerArr);
                Courier courier = Assignment.findCourierByID(ID, Assignment.courierArr);
                Manager manager = Assignment.findManagerByID(ID, Assignment.managerArr);
                try{
                    if(!customer.equals(null)){
                    IDTextField.setText(String.valueOf(customer.getId()));
                    roleComboBox.setSelectedItem("CUSTOMER");
                    nameTextField.setText(customer.getName());
                    telephoneTextField.setText(String.valueOf(customer.getTelephone()));
                    addressTextField.setText(customer.getAddress());
                    passwordTextField.setText("");
                    }
                } catch (Exception Ex) {}
                try{
                    if(!courier.equals(null)){
                        IDTextField.setText(String.valueOf(courier.getId()));
                        roleComboBox.setSelectedItem("COURIER");
                        nameTextField.setText(courier.getName());
                        telephoneTextField.setText(String.valueOf(courier.getTelephone()));
                        addressTextField.setText(courier.getAddress());
                        passwordTextField.setText(courier.getPassword());
                    }
                } catch (Exception Ex) {}
                try{
                    if(!manager.equals(null)){
                        IDTextField.setText(String.valueOf(manager.getId()));
                        roleComboBox.setSelectedItem("MANAGER");
                        nameTextField.setText(manager.getName());
                        telephoneTextField.setText(String.valueOf(manager.getTelephone()));
                        addressTextField.setText(manager.getAddress());
                        passwordTextField.setText(manager.getPassword());
                    }
                } catch (Exception Ex) {}
            } catch (Exception Ex) {
                System.out.print(Ex);
            }
        };
        if(e.getSource() == searchBtn){
            tableModel.removeRow(9);
            tableModel.removeRow(8);
            tableModel.removeRow(7);
            tableModel.removeRow(6);
            tableModel.removeRow(5);
            tableModel.removeRow(4);
            tableModel.removeRow(3);
            tableModel.removeRow(2);
            tableModel.removeRow(1);
            tableModel.removeRow(0);
            int i=0;
            if(searchTextField.getText().equals("")){
            } else {
                for(Customer customer : Assignment.customerArr){
                    int ID = -1;
                    boolean nameMatch = false;
                    try{
                        nameMatch = customer.getName().toLowerCase().contains(searchTextField.getText().toLowerCase());
                    } catch (Exception Ex) {}
                    try{
                        ID = Integer.parseInt(searchTextField.getText());
                    } catch (Exception Ex) {}
                    try{
                        if(customer.getId() == ID || nameMatch) {
                            if(i != 9 && i<10){
                                Object[] objs = {customer.getId(),customer.getName(),customer.getTelephone(),customer.getAddress(),customer.getRole(),""};
                                tableModel.addRow(objs);
                                i++;
                            } else if(i<10) {
                                Object[] objs = {"+","+","+","+","+","+"};
                                tableModel.addRow(objs);
                                i++;
                            }
                        }
                    } catch(Exception Ex) {}
                }
                for(Courier courier : Assignment.courierArr){
                    int ID = -1;
                    boolean nameMatch = false;
                    try{
                        nameMatch = courier.getName().toLowerCase().contains(searchTextField.getText().toLowerCase());
                    } catch (Exception Ex) {}
                    try{
                        ID = Integer.parseInt(searchTextField.getText());
                    } catch (Exception Ex) {}
                    try{
                        if(courier.getId() == ID || nameMatch) {
                            if(i != 9 && i<10){
                                Object[] objs = {courier.getId(),courier.getName(),courier.getTelephone(),courier.getAddress(),courier.getRole(),courier.getPassword()};
                                tableModel.addRow(objs);
                                i++;
                            } else if(i<10) {
                                Object[] objs = {"+","+","+","+","+","+"};
                                tableModel.addRow(objs);
                                i++;
                            }
                        }
                    } catch(Exception Ex) {}
                }
                for(Manager manager : Assignment.managerArr){
                    int ID = -1;
                    boolean nameMatch = false;
                    try{
                        nameMatch = manager.getName().toLowerCase().contains(searchTextField.getText().toLowerCase());
                    } catch (Exception Ex) {}
                    try{
                        ID = Integer.parseInt(searchTextField.getText());
                    } catch (Exception Ex) {}
                    try{
                        if(manager.getId() == ID || nameMatch) {
                            if(i != 9 && i<10){
                                Object[] objs = {manager.getId(),manager.getName(),manager.getTelephone(),manager.getAddress(),manager.getRole(),manager.getPassword()};
                                tableModel.addRow(objs);
                                i++;
                            } else if(i<10) {
                                Object[] objs = {"+","+","+","+","+","+"};
                                tableModel.addRow(objs);
                                i++;
                            }
                        }
                    } catch(Exception Ex) {}
                }
            }
            for(; i<10; i++){
                Object[] objs = {"","","","","",""};
                tableModel.addRow(objs);
            }
        }
        if(e.getSource() == newIDBtn){
            int ID = Assignment.getNewID(Assignment.customerArr, Assignment.courierArr , Assignment.managerArr);
            IDTextField.setText(String.valueOf(ID));
        }
        if(e.getSource() == deleteBtn){
            int  ID;
            try{
                if(!IDTextField.getText().equals(null)){
                    ID = Integer.parseInt(IDTextField.getText());
                    //Activate field for clearText
                    String s = nameTextField.getText();
                    s = telephoneTextField.getText();
                    s = addressTextField.getText();
                    s = roleComboBox.getSelectedItem().toString();
                    s = passwordTextField.getText();
                    
                    if(Assignment.findCourierByID(ID, Assignment.courierArr) != null){
                        Assignment.courierArr.remove(Assignment.findCourierByID(ID, Assignment.courierArr));
                        this.clearPersonTextField();
                    } else if(Assignment.findCustomerByID(ID, Assignment.customerArr) != null){
                        Assignment.customerArr.remove(Assignment.findCustomerByID(ID, Assignment.customerArr));
                        this.clearPersonTextField();
                    } else if(Assignment.findManagerByID(ID, Assignment.managerArr) != null){
                        Assignment.managerArr.remove(Assignment.findManagerByID(ID, Assignment.managerArr));
                        this.clearPersonTextField();
                    } else {
                        JOptionPane.showMessageDialog(this,"ID not found");
                    }
                } else {
                    throw new Exception("");
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"ID not valid");
            }
        }
        if(e.getSource() == changeBtn){
            int  ID = 0;
            String name = null;
            int telephone = 0;
            String address = null;
            RoleEnum role = null;
            String password = null;
            try{
                if(!IDTextField.getText().equals("")&&!nameTextField.getText().equals("")&&!telephoneTextField.getText().equals("")&&!addressTextField.getText().equals("")&&!roleComboBox.getSelectedItem().toString().equals("")){
                    ID = Integer.parseInt(IDTextField.getText());
                    if(ID <= Assignment.getNewID(Assignment.customerArr, Assignment.courierArr, Assignment.managerArr)){
                        //remove old data (if exist)
                        try{Assignment.customerArr.remove(Assignment.findCustomerByID(ID,Assignment.customerArr));} catch (Exception Ex) {}
                        try{Assignment.courierArr.remove(Assignment.findCourierByID(ID,Assignment.courierArr));} catch (Exception Ex) {}
                        try{Assignment.managerArr.remove(Assignment.findManagerByID(ID,Assignment.managerArr));} catch (Exception Ex) {}

                        name = nameTextField.getText();
                        telephone = Integer.parseInt(telephoneTextField.getText());
                        address = addressTextField.getText();
                        String roleString = roleComboBox.getSelectedItem().toString();
                        role = RoleEnum.valueOf(roleString); 
                        switch(role){
                            case CUSTOMER:
                                password=passwordTextField.getText();
                                Customer customer = new Customer(ID, name, telephone, address, role);
                                Assignment.customerArr.add(customer);
                                this.clearPersonTextField();
                                break;
                            case COURIER:
                                if(!passwordTextField.getText().equals("")){
                                    password=passwordTextField.getText();
                                    Courier courier = new Courier(ID, name, telephone, address, role, password);
                                    Assignment.courierArr.add(courier);
                                    this.clearPersonTextField();
                                } else {
                                    JOptionPane.showMessageDialog(this,"Employee must have password");
                                }
                                break;
                            case MANAGER:
                                if(!passwordTextField.getText().equals("")){
                                    password=passwordTextField.getText();
                                    Manager manager = new Manager(ID, name, telephone, address, role, password);
                                    Assignment.managerArr.add(manager);
                                    this.clearPersonTextField();
                                } else {
                                    JOptionPane.showMessageDialog(this,"Employee must have password");
                                }
                                break;
                        } 
                    } else {
                            JOptionPane.showMessageDialog(this,"ID not exist");
                    }
                } else {
                    JOptionPane.showMessageDialog(this,"ID, name, telephone, address, role must be filled");
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"Error! Please try again");
            }
        }
        if(e.getSource() == findRatingBtn){
            tableModel3.removeRow(9);
            tableModel3.removeRow(8);
            tableModel3.removeRow(7);
            tableModel3.removeRow(6);
            tableModel3.removeRow(5);
            tableModel3.removeRow(4);
            tableModel3.removeRow(3);
            tableModel3.removeRow(2);
            tableModel3.removeRow(1);
            tableModel3.removeRow(0);
            int i=0;
            int ratingTotal = 0;
            if(!IDRatingTextField.getText().equals("")){
                for(int i2 = Assignment.orderArr.size()-1; i2 >=0 ; i2--){
                    Order order = Assignment.orderArr.get(i2);
                    int ORDER_ID = -1;
                    try{ ORDER_ID = Integer.parseInt(searchOrderTextField.getText()); } catch (Exception Ex) {}
                    try{
                        if(order.getAssignedCourier().getId() == Integer.parseInt(IDRatingTextField.getText())) {
                            if(i != 9 && i<10){
                                Object[] objs = {order.getOrderId(),String.valueOf(order.getRating().getValue()),order.getFeedback()};
                                tableModel3.addRow(objs);
                                i++;
                            } else if(i<10) {
                                Object[] objs = {"+","+","+","+","+","+","+","+","+","+","+"};
                                tableModel3.addRow(objs);
                                i++;
                            }
                            ratingTotal = ratingTotal+order.getRating().getValue();
                        }
                    } catch(Exception Ex) {}
                }
            }
            amountRatingLabel2.setText(String.valueOf(ratingTotal));
            for(; i<10; i++){
                Object[] objs = {"","","","","","","","","",""};
                tableModel3.addRow(objs);
            }
            
        }
        if(e.getSource() == searchOrderBtn){
            tableModel2.removeRow(9);
            tableModel2.removeRow(8);
            tableModel2.removeRow(7);
            tableModel2.removeRow(6);
            tableModel2.removeRow(5);
            tableModel2.removeRow(4);
            tableModel2.removeRow(3);
            tableModel2.removeRow(2);
            tableModel2.removeRow(1);
            tableModel2.removeRow(0);
            int i=0;
            if(!searchOrderTextField.getText().equals("")){
                for(int i2 = Assignment.orderArr.size()-1; i2 >=0 ; i2--){
                    Order order = Assignment.orderArr.get(i2);
                    int ORDER_ID = -1;
                    String customerName = "";
                    boolean customerMatch = false;
                    String courierName = "";
                    boolean courierMatch = false;
                    try{ ORDER_ID = Integer.parseInt(searchOrderTextField.getText()); } catch (Exception Ex) {}
                    try{ 
                        customerName = order.getOwningCustomer().getName();
                        customerMatch = customerName.toLowerCase().contains(String.valueOf(searchOrderTextField.getText()).toLowerCase());
                    } catch (Exception Ex) {}
                    try{ 
                        courierName = order.getAssignedCourier().getName(); 
                        courierMatch = courierName.toLowerCase().contains(searchOrderTextField.getText().toLowerCase());
                    } catch (Exception Ex) {}
                    try{
                        if(order.getOrderId() == ORDER_ID || customerMatch || courierMatch) {
                            if(i != 9 && i<10){
                                String courierID = "";
                                try{ courierID = String.valueOf(order.getAssignedCourier().getId()); } catch (Exception Ex) {}
                                Object[] objs = {order.getOrderId(),courierID,
                                    order.getOwningCustomer().getId(),order.getCharge(),order.getDepartureAddress(),
                                    order.getDestinationAddress(),order.getSTART_TIME(),order.getEndTime(),
                                    order.getRating().toString(),order.getFeedback(),order.getStatus().toString()};
                                tableModel2.addRow(objs);
                                i++;
                            } else if(i<10) {
                                Object[] objs = {"+","+","+","+","+","+","+","+","+","+","+"};
                                tableModel2.addRow(objs);
                                i++;
                            }
                        }
                    } catch(Exception Ex) {System.out.println(Ex);}
                }
            }
            for(; i<10; i++){
                Object[] objs = {"","","","","","","","","",""};
                tableModel2.addRow(objs);
            }
        }
        if(e.getSource() == newOrderIDBtn){
            int ORDER_ID = ORDER_ID = Assignment.getNewID(Assignment.orderArr);
            orderIDTextField.setText(String.valueOf(ORDER_ID));
            endTextField.setText("0001-01-01 00:00");
        }
        if(e.getSource() == deleteOrderBtn){
            int ORDER_ID;
            try{
                if(!orderIDTextField.getText().equals(null)){
                    ORDER_ID = Integer.parseInt(IDTextField.getText());
                    //Activate field for clearText
                    String s = orderIDTextField.getText();
                    s = assignedCourierIDTextField.getText();
                    s = owningCustomerIDTextField.getText();
                    s = chargeTextField.getText();
                    s = departureTextField.getText();
                    s = destinationTextField.getText();
                    s = startTextField.getText();
                    s = endTextField.getText();
                    s = ratingComboBox.getSelectedItem().toString();
                    s = feedbackTextField.getText();
                    s = statusComboBox.getSelectedItem().toString();
                    
                    if(Assignment.findOrderByID(ORDER_ID, Assignment.orderArr) != null){
                        Assignment.orderArr.remove(Assignment.findOrderByID(ORDER_ID, Assignment.orderArr));
                        clearOrderTextField();
                    } else {
                        JOptionPane.showMessageDialog(this,"ID not found");
                    }
                } else {
                    throw new Exception("");
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"ID not valid");
            }
        }
        if(e.getSource() == orderIDTextField){
            try{
                int ORDER_ID = Integer.parseInt(orderIDTextField.getText());
                Order order = Assignment.findOrderByID(ORDER_ID, Assignment.orderArr);
                orderIDTextField.setText(String.valueOf(order.getOrderId()));
                try{ assignedCourierIDTextField.setText(String.valueOf(order.getAssignedCourier().getId())); } catch (Exception Ex) {}
                owningCustomerIDTextField.setText(String.valueOf(order.getOwningCustomer().getId()));
                chargeTextField.setText(String.valueOf(order.getCharge()));
                departureTextField.setText(order.getDepartureAddress());
                destinationTextField.setText(order.getDestinationAddress());
                String str = order.getSTART_TIME().toString();
                str = str.replace("T"," ");
                startTextField.setText(str);
                str = order.getEndTime().toString();
                str = str.replace("T"," ");
                endTextField.setText(str);
                ratingComboBox.setSelectedItem(order.getRating().toString());
                feedbackTextField.setText(order.getFeedback());
                statusComboBox.setSelectedItem(order.getStatus().toString());
            } catch (Exception Ex) {}
        }
        if(e.getSource() == printOrderBtn){
            int ORDER_ID = 0;
            try{
                if(!orderIDTextField.getText().equals("")){
                    ORDER_ID = Integer.parseInt(orderIDTextField.getText());
                    if(ORDER_ID > 0 && 
                    !owningCustomerIDTextField.getText().equals("") && 
                    !chargeTextField.getText().equals("") && 
                    !departureTextField.getText().equals("") && 
                    !destinationTextField.getText().equals("") && 
                    !startTextField.getText().equals("") && 
                    !endTextField.getText().equals("") && 
                    !ratingComboBox.getSelectedItem().toString().equals("") &&
                    !statusComboBox.getSelectedItem().toString().equals("") ){
                        //get reference and remove old data (if exist)
                        Order oldOrder = null;
                        try{
                            oldOrder = Assignment.findOrderByID(ORDER_ID, Assignment.orderArr);
                            Assignment.orderArr.remove(Assignment.findOrderByID(ORDER_ID, Assignment.orderArr));
                        } catch (Exception Ex) {}
                        
                        int courierID = -1;
                        try{ courierID = Integer.parseInt(assignedCourierIDTextField.getText()); } catch (Exception Ex) {}
                        Courier assignedCourier = null;
                        if(Assignment.findCourierByID(courierID, courierArr) == null){
                        } else {
                            assignedCourier = assignedCourier.findCourierByID(courierID, courierArr);
                        }
                        
                        int customerID = Integer.parseInt(owningCustomerIDTextField.getText());
                        if(Assignment.findCustomerByID(customerID, customerArr) == null) {throw new Exception("Customer did not exist!");}
                        Customer owningCustomer = null;
                        owningCustomer = Assignment.findCustomerByID(customerID, customerArr);
                        
                        int charge = Integer.parseInt(chargeTextField.getText());
                        String departureAddress = departureTextField.getText();
                        String destinationAddress = destinationTextField.getText();
                        
                        String str = startTextField.getText();
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime START_TIME = LocalDateTime.parse(str, formatter);
                        try { 
                            //if oldOrder exist and start time is not equal/ changed throw error as start time cannot be changed
                            if(!oldOrder.getSTART_TIME().equals(START_TIME))  {
                                throw new Exception ("START_TIME cannot be changed!");
                            }
                        } catch (Exception Ex) {}
                        
                        str = endTextField.getText();
                        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime endTime = LocalDateTime.parse(str, formatter);

                        String ratingString = ratingComboBox.getSelectedItem().toString();
                        RatingEnum rating = RatingEnum.valueOf(ratingString);

                        String feedback = feedbackTextField.getText();

                        String statusString = statusComboBox.getSelectedItem().toString();
                        StatusEnum status = StatusEnum.valueOf(statusString);
                        
                        Order order = new Order(ORDER_ID, assignedCourier, owningCustomer, charge, departureAddress, destinationAddress, START_TIME, endTime, rating, feedback, status);
                        orderArr.add(order);
                        clearOrderTextField();
                        try {
                            PDDocument doc = new PDDocument();
                            PDPage myPage = new PDPage();
                            doc.addPage(myPage);
                            try (PDPageContentStream cont = new PDPageContentStream(doc, myPage)) {
                                cont.beginText();
                                cont.setFont(PDType1Font.TIMES_ROMAN, 12);
                                cont.setLeading(15f);
                                cont.newLineAtOffset(25, 700);
                                String title1 = "============RECEIPT============";
                                cont.showText(title1);
                                cont.newLine();
                                String title2 = "Manager ID : "+String.valueOf(currentLogin.getId())+" Name : "+currentLogin.getName();
                                cont.showText(title2);
                                cont.newLine();
                                String title3 = "===============================";
                                cont.showText(title3);
                                cont.newLine();
                                String line1 = "Order ID : "+String.valueOf(ORDER_ID);
                                cont.showText(line1);
                                cont.newLine();
                                String line2;
                                try{
                                    line2 = "Assigned courier ID : "+String.valueOf(assignedCourier.getId())+" Name : "+assignedCourier.getName(); 
                                } 
                                catch (Exception ex){
                                    line2 = "Assigned courier ID : Not assigned Name : Not assigned"; 
                                }
                                cont.showText(line2);
                                cont.newLine();
                                String line3 = "Owning customer : "+owningCustomer.getName();
                                cont.showText(line3);
                                cont.newLine();
                                String line4 = "Charge : "+String.valueOf(charge);
                                cont.showText(line4);
                                cont.newLine();
                                String line5 = "Departure Address : "+departureAddress;
                                cont.showText(line5);
                                cont.newLine();
                                String line6 = "Destination Address : "+destinationAddress;
                                cont.showText(line6);
                                cont.newLine();
                                String line7 = "Start time : "+str;
                                cont.showText(line7);
                                cont.newLine();
                                str = endTime.toString();
                                str.replace("T", " ");
                                String line8 = "End time : "+endTime.toString();
                                cont.showText(line8);
                                cont.newLine();
                                String line9 = "Rating : "+rating.toString();
                                cont.showText(line9);
                                cont.newLine();
                                String line10 = "Feedback : "+feedback;
                                cont.showText(line10);
                                cont.newLine();
                                String line11 = "Status : "+status.toString();
                                cont.showText(line11);
                                cont.newLine();
                                cont.endText();
                            }
                            doc.save("Receipt of order ID "+ORDER_ID+".pdf");
                            JOptionPane.showMessageDialog(this,"Data are saved and printed into \""+"Receipt of order ID "+ORDER_ID+".pdf\"");
                        } catch (Exception ex) {
                            JOptionPane.showMessageDialog(this,"Data are saved but print to pdf Error");
                        }
                    } else {
                            JOptionPane.showMessageDialog(this,"All table except for feedback are required");
                    }
                } else {
                    
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"Error! please try again");
            }
        }
        if(e.getSource() == changeOrderBtn){
            int ORDER_ID = 0;
            try{
                if(!orderIDTextField.getText().equals("")){
                    ORDER_ID = Integer.parseInt(orderIDTextField.getText());
                    if(ORDER_ID > 0 && 
                    !owningCustomerIDTextField.getText().equals("") && 
                    !chargeTextField.getText().equals("") && 
                    !departureTextField.getText().equals("") && 
                    !destinationTextField.getText().equals("") && 
                    !startTextField.getText().equals("") && 
                    !endTextField.getText().equals("") && 
                    !ratingComboBox.getSelectedItem().toString().equals("") &&
                    !statusComboBox.getSelectedItem().toString().equals("") ){
                        //get reference and remove old data (if exist)
                        Order oldOrder = null;
                        try{
                            oldOrder = Assignment.findOrderByID(ORDER_ID, Assignment.orderArr);
                            Assignment.orderArr.remove(Assignment.findOrderByID(ORDER_ID, Assignment.orderArr));
                        } catch (Exception Ex) {}
                        
                        int courierID = -1;
                        try{ courierID = Integer.parseInt(assignedCourierIDTextField.getText()); } catch (Exception Ex) {}
                        Courier assignedCourier = null;
                        if(Assignment.findCourierByID(courierID, courierArr) == null){
                        } else {
                            assignedCourier = assignedCourier.findCourierByID(courierID, courierArr);
                        }
                        
                        int customerID = Integer.parseInt(owningCustomerIDTextField.getText());
                        if(Assignment.findCustomerByID(customerID, customerArr) == null) {throw new Exception("Customer did not exist!");}
                        Customer owningCustomer = null;
                        owningCustomer = Assignment.findCustomerByID(customerID, customerArr);
                        
                        int charge = Integer.parseInt(chargeTextField.getText());
                        String departureAddress = departureTextField.getText();
                        String destinationAddress = destinationTextField.getText();
                        
                        String str = startTextField.getText();
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime START_TIME = LocalDateTime.parse(str, formatter);
                        try { 
                            //if oldOrder exist and start time is not equal/ changed throw error as start time cannot be changed
                            if(!oldOrder.getSTART_TIME().equals(START_TIME))  {
                                throw new Exception ("START_TIME cannot be changed!");
                            }
                        } catch (Exception Ex) {}
                        
                        str = endTextField.getText();
                        formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
                        LocalDateTime endTime = LocalDateTime.parse(str, formatter);

                        String ratingString = ratingComboBox.getSelectedItem().toString();
                        RatingEnum rating = RatingEnum.valueOf(ratingString);

                        String feedback = feedbackTextField.getText();

                        String statusString = statusComboBox.getSelectedItem().toString();
                        StatusEnum status = StatusEnum.valueOf(statusString);
                        
                        Order order = new Order(ORDER_ID, assignedCourier, owningCustomer, charge, departureAddress, destinationAddress, START_TIME, endTime, rating, feedback, status);
                        orderArr.add(order);
                        clearOrderTextField();
                    } else {
                            JOptionPane.showMessageDialog(this,"All table except for feedback are required");
                    }
                } else {
                    
                }
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"Error! please try again");
            }
        }
        if(e.getSource() == nowBtn){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime nowTime = LocalDateTime.now();
            String str = LocalDateTime.now().toString();
            str = str.replace("T"," ");
            str = str.substring(0,16);
            startTextField.setText(str);
        }
        if(e.getSource() == nowBtn2){
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
            LocalDateTime nowTime = LocalDateTime.now();
            String str = LocalDateTime.now().toString();
            str = str.replace("T"," ");
            str = str.substring(0,16);
            endTextField.setText(str);
        }
        if(e.getSource() == backBtn){
            this.setVisible(false);
            Assignment.loginPage.setVisible(true);
        }
    }
}

