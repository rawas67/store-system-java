/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import static assignment.Assignment.orderArr;
import assignment.people.Courier;
import assignment.people.Customer;
import assignment.people.Manager;
import assignment.people.RoleEnum;

import java.awt.Button;
import java.awt.Font;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.BoxLayout;

/**
 *
 * @author asus
 */
public class LoginPage extends JFrame implements ActionListener {
    private Label customerLabel, courierLabel, managerLabel;
    private TextField nameCustomerTextField, nameCourierTextField, passCourierTextField, nameManagerTextField, passManagerTextField;
    private Button loginCustomerBtn, loginCourierBtn, loginManagerBtn, exitBtn;
    
    public LoginPage(){
        this.setSize(300,350);
        setLocation(300,200);
        //close the GUI and stop the system
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        Font f = new Font(Font.SANS_SERIF,Font.BOLD,16);
        
        customerLabel = new Label("Customer Login");
        customerLabel.setFont(f);
        courierLabel = new Label("Courier Login");
        courierLabel.setFont(f);
        managerLabel = new Label("Manager Login");
        managerLabel.setFont(f);
        
        nameCustomerTextField = new TextField();
        nameCourierTextField = new TextField();
        passCourierTextField = new TextField();
        nameManagerTextField = new TextField();
        passManagerTextField = new TextField();
        
        loginCustomerBtn = new Button("Login Courier");
        loginCustomerBtn.addActionListener(this);
        loginCourierBtn = new Button("Login Courier");
        loginCourierBtn.addActionListener(this);
        loginManagerBtn = new Button("Login Manager");
        loginManagerBtn.addActionListener(this);
        exitBtn = new Button("Exit");
        exitBtn.addActionListener(this);
        
        getContentPane().setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));
        
        add(customerLabel);
        add(nameCustomerTextField);
        add(loginCustomerBtn);
        
        add(courierLabel);
        add(nameCourierTextField);
        add(passCourierTextField);
        add(loginCourierBtn);
        
        add(managerLabel);
        add(nameManagerTextField);
        add(passManagerTextField);
        add(loginManagerBtn);
        add(exitBtn);
        
        //If no manager create new manager
        
        while(Assignment.managerArr.isEmpty()) {
            try{
                int id = Assignment.getNewID(Assignment.customerArr, Assignment.courierArr , Assignment.managerArr);
                String name = JOptionPane.showInputDialog("Name:");
                int telephone = Integer.parseInt(JOptionPane.showInputDialog("telephone:"));
                String address = JOptionPane.showInputDialog("address:");
                RoleEnum role = RoleEnum.MANAGER;
                String password = JOptionPane.showInputDialog("Password:");
                Manager manager = new Manager(id, name, telephone, address, role, password);
                Assignment.managerArr.add(manager);
                JOptionPane.showMessageDialog(this,"Your ID is "+id);
            } catch (Exception Ex) {
                JOptionPane.showMessageDialog(this,"Error! please try again");
            }
        }
}
        
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource() == loginCustomerBtn){
            try {
                int id = Integer.parseInt(nameCustomerTextField.getText());
                Customer customer = Assignment.findCustomerByID(id, Assignment.customerArr);
                if(!customer.equals(null)){
                    nameCustomerTextField.setText("");
                    this.setVisible(false);
                    Assignment.customerPage.loadProfileTextField(customer);
                    Assignment.customerPage.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this,"Invalid ID");
                }
            } catch(Exception ex){
               JOptionPane.showMessageDialog(this,"Invalid ID");
            }
        }
        if(e.getSource() == loginCourierBtn){
            try {
                int id = Integer.parseInt(nameCourierTextField.getText());
                Courier courier = Assignment.findCourierByID(id, Assignment.courierArr);
                String pass = passCourierTextField.getText();
                if(pass.equals(courier.getPassword())){
                    nameCourierTextField.setText("");
                    passCourierTextField.setText("");
                    this.setVisible(false);
                    Assignment.courierPage.loadProfileTextField(courier);
                    Assignment.courierPage.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this,"Invalid password");
                }
            } catch(Exception ex){
               JOptionPane.showMessageDialog(this,"Invalid ID or password");
            }
        }
        if(e.getSource() == loginManagerBtn){
            try {
                int id = Integer.parseInt(nameManagerTextField.getText());
                Manager manager = Assignment.findManagerByID(id, Assignment.managerArr);
                String pass = passManagerTextField.getText();
                if(pass.equals(manager.getPassword())){
                    nameManagerTextField.setText("");
                    passManagerTextField.setText("");
                    this.setVisible(false);
                    Assignment.managerPage.setCurrentLogin(manager);
                    Assignment.managerPage.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this,"Invalid password");
                }
            } catch(Exception ex){
               JOptionPane.showMessageDialog(this,"Invalid ID or password");
            }
        }
        if(e.getSource() == exitBtn){
            try {
                PrintWriter p = new PrintWriter("person.txt");
                for(int i=0; i<Assignment.customerArr.size(); i++){
                    Customer customer = Assignment.customerArr.get(i);
                    p.println(customer.getId());
                    p.println(customer.getName());
                    p.println(customer.getTelephone());
                    p.println(customer.getAddress());
                    p.println(customer.getRole().toString());
                    p.println("");
                }
                for(int i=0; i<Assignment.courierArr.size(); i++){
                    Courier courier = Assignment.courierArr.get(i);
                    p.println(courier.getId());
                    p.println(courier.getName());
                    p.println(courier.getTelephone());
                    p.println(courier.getAddress());
                    p.println(courier.getRole().toString());
                    p.println(courier.getPassword());
                    p.println("");
                }
                for(int i=0; i<Assignment.managerArr.size(); i++){
                    Manager manager = Assignment.managerArr.get(i);
                    p.println(manager.getId());
                    p.println(manager.getName());
                    p.println(manager.getTelephone());
                    p.println(manager.getAddress());
                    p.println(manager.getRole().toString());
                    p.println(manager.getPassword());
                    p.println("");
                }
                p.close();
            } catch (FileNotFoundException ex) {
                System.out.println(ex);
            }
            try {
                PrintWriter p = new PrintWriter("order.txt");
                for(int i=0; i<Assignment.orderArr.size(); i++){
                    Order order = orderArr.get(i);
                    
                    p.println(order.getOrderId());
                    try{
                        p.println(order.getAssignedCourier().getId());
                    } catch (Exception Ex) {
                        p.println("");
                    }
                    p.println(order.getOwningCustomer().getId());
                    p.println(order.getCharge());
                    p.println(order.getDepartureAddress());
                    p.println(order.getDestinationAddress());
                    p.println(order.getSTART_TIME().toString());
                    p.println(order.getEndTime().toString());
                    p.println(order.getRating().toString());
                    p.println(order.getFeedback());
                    p.println(order.getStatus().toString());
                    p.println("");
                }
                p.close();
                System.exit(0);
            } catch (FileNotFoundException ex) {
                System.out.println(ex);
            }
        }
    }
}
