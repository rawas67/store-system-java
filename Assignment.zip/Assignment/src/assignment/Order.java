/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package assignment;

import assignment.people.Courier;
import assignment.people.Customer;
import java.time.LocalDateTime;

/**
 *
 * @author asus
 */
public class Order {
    private final int ORDER_ID;
    private Courier assignedCourier;
    private Customer owningCustomer;
    private String departureAddress;
    private String destinationAddress;
    private int charge;
    private final LocalDateTime START_TIME;
    private LocalDateTime endTime;
    private RatingEnum rating;
    private String feedback;
    private StatusEnum status;
    
    public Order(int ORDER_ID, Courier assignedCourier, Customer owningCustomer, 
    int charge, String departureAddress, String destinationAddress,
    LocalDateTime START_TIME, LocalDateTime endTime, RatingEnum rating, 
    String feedback, StatusEnum status){
        this.ORDER_ID = ORDER_ID;
        this.assignedCourier = assignedCourier;
        this.owningCustomer = owningCustomer;
        this.charge = charge;
        this.departureAddress = departureAddress;
        this.destinationAddress = destinationAddress;
        this.START_TIME = START_TIME;
        this.endTime = endTime;
        this.rating = rating;
        this.feedback = feedback;
        this.status = status;
    }
    
    public int getOrderId(){
        return ORDER_ID;
    }
    
    public Courier getAssignedCourier(){
        return assignedCourier;
    }
    public void setAssignedCourier(Courier assignedCourier){
        this.assignedCourier = assignedCourier;
    }
    
    public Customer getOwningCustomer(){
        return owningCustomer;
    }
    public void setOwningCustomer(Customer owningCustomer){
        this.owningCustomer = owningCustomer;
    }
    
    public String getDepartureAddress(){
        return departureAddress;
    }
    public void setDepartureAddress(String departureAddress){
        this.departureAddress = departureAddress;
    }
    
    public String getDestinationAddress(){
        return destinationAddress;
    }
    public void setDestinationAddress(String destinationAddress){
        this.destinationAddress = destinationAddress;
    }
    
    public int getCharge(){
        return charge;
    }
    public void set(int charge){
        this.charge = charge;
    }
    
    public LocalDateTime getSTART_TIME(){
        return START_TIME;
    }
    
    public LocalDateTime getEndTime(){
        return endTime;
    }
    public void set(LocalDateTime endTime){
        this.endTime = endTime;
    }
    
    public RatingEnum getRating(){
        return rating;
    }
    public void setRating(RatingEnum rating){
        this.rating = rating;
    }
    
    public String getFeedback(){
        return feedback;
    }
    public void setFeedback(String feedback){
        this.feedback = feedback;
    }
    public StatusEnum getStatus(){
        return status;
    }
    public void setStatus(StatusEnum status){
        this.status = status;
    }
}
